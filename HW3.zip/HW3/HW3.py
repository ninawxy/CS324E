import operator

def main():
    file = open("fish.txt", "r")

    v1 = file.readlines()
    v2 = []

    # remove '\n'
    for item in v1:
        v2.append(item.rstrip())

    #list of all words
    v3 = []
    for item in v2:
        v3.extend(item.split(" "))

    #remove non-letter and change to lowercase
    v4 = []
    for item in v3:
        inter = ""
        for s in item:
            if s.isalpha() == False:
                s = ""
            else:
                s = s.lower()
            inter += s
        v4.append(inter)


    #remove empty items ni new reading
    v4 = list(filter(None, v4))

    #output file contains all words that appear in the file
    all = open("allwords.txt", "w")
    for item in v4:
        all.write(item + "\n")


    #dictionary that counts the occurance of each word
    dict = {}
    for item in v4:
        if item in dict:
            dict[item] += 1
        else:
            dict[item] = 1

    #output unique words
    unique = open("uniquewords.txt", "w")
    for item in dict:
        if dict[item] == 1:
            unique.write(item + "\n")

    #create word frequency file
    freq_dict = {}
    for key in dict:
        if dict[key] in freq_dict:
            freq_dict[dict[key]] += 1
        else:
            freq_dict[dict[key]] = 1

    #get them sorted by key in increasing order
    sorted_freq = sorted(freq_dict.items(), key=operator.itemgetter(0))

    #output to frequency file
    freq = open("wordfrequency.txt", "w")
    for item in sorted_freq:
        freq.write(str(item[0]) + " : " + str(item[1]) + "\n")

    #print(sorted_freq)
    #print(dict)



main()